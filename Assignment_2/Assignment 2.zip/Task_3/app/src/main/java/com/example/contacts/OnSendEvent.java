package com.example.contacts;

public interface OnSendEvent {
     void SendListner(String number);
}
