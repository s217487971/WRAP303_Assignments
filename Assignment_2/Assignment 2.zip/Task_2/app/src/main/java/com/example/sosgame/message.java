package com.example.sosgame;

public interface message {
    public void onChange();
}
