package com.example.sosgame;

public class line {
    public int row1;
    public int col1;
    public int row2;
    public int col2;
    public int player;

    public line(int row1,int col1, int row2, int col2,int player)
    {
        this.row1 = row1;
        this.col1 = col1;
        this.row2 = row2;
        this.col2 = col2;
        this.player = player;
    }
}
