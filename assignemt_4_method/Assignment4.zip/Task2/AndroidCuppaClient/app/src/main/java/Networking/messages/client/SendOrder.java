package Networking.messages.client;

import Networking.SubscriberClient;

import Networking.messages.Message;


public class SendOrder extends Message<SubscriberClient> {
    private static final long serialVersionUID = 78L;

    int[] quantities;
    String telephone;
    String handle;
    String date;
    String time;

    public SendOrder( int[] products, String telephone, String handle, String date, String time)
    {
        this.date =date;
        this.time = time;
        this.telephone = telephone;
        this.handle = handle;
        this.quantities = products;
    }
    @Override
    public String toString() {

        return String.format("SendChatMessage(' Send Order')");
    }

}
