package Networking.messages;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

public class product implements Parcelable, Serializable {
    private static final long serialVersionUID = 94554L;

    /**
     * We make the product Parcelable so that we can pass it across different activities
     * The image Resource is 0 if the product has no picture
     */


    private String ProductID;
    private String ProductName;
    private String ProductDescription;
    private double ProductPrice;
    private int imageResource;


    public product(String productID, String productName, String productDescription, double productPrice, int imageResource) {
        ProductID = productID;
        ProductName = productName;
        ProductDescription = productDescription;
        ProductPrice = productPrice;
        this.imageResource = imageResource;
    }

    public product(String productID, String productName, String productDescription, double productPrice) {
        ProductID = productID;
        ProductName = productName;
        ProductDescription = productDescription;
        ProductPrice = productPrice;
    }

    public String getProductID() {
        return ProductID;
    }


    public String getProductName() {
        return ProductName;
    }

    public void setProductName(String productName) {
        ProductName = productName;
    }

    public String getProductDescription() {
        return ProductDescription;
    }

    public void setProductDescription(String productDescription) {
        ProductDescription = productDescription;
    }

    public double getProductPrice() {
        return ProductPrice;
    }

    public void setProductPrice(double productPrice) {
        ProductPrice = productPrice;
    }

    public int getImageResource() {
        return imageResource;
    }

    public void setImageResource(int imageResource) {
        this.imageResource = imageResource;
    }

    protected product(Parcel in) {
        ProductID = in.readString();
        ProductName = in.readString();
        ProductDescription = in.readString();
        ProductPrice = in.readDouble();
        imageResource = in.readInt();
    }

    public static final Creator<product> CREATOR = new Creator<product>() {
        @Override
        public product createFromParcel(Parcel in) {
            return new product(in);
        }

        @Override
        public product[] newArray(int size) {
            return new product[size];
        }
    };
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(ProductID);
        parcel.writeString(ProductName);
        parcel.writeString(ProductDescription);
        parcel.writeDouble(ProductPrice);
        parcel.writeInt(imageResource);
    }
}
